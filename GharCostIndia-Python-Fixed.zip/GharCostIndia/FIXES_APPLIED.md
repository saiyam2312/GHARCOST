# GharCost India — Fixes Applied

This package contains the repaired no-Streamlit Python build.

## Corrected

- Calculator input parsing now rejects `NaN`, positive/negative infinity, values outside supported project-size/rate ranges, invalid units and invalid percentage allowances.
- The calculator validates every calculated output so `NaN`/`Infinity` cannot appear in budget totals.
- Calculator page, printable report and CSV export now use one shared calculation function, preventing formula/validation differences between outputs.
- Explore India now applies the selected city filter and includes an `All cities` option.
- Admin listing input rejects non-finite, negative, excessively large and malformed values.
- Listing JSON is schema-validated, duplicate IDs are rejected, and writes use an atomic temporary-file replacement.
- Concurrent add/delete/reset operations are protected by a shared data lock.
- Admin access is local-only by default. Public admin access is disabled unless `ADMIN_PASSWORD` is configured; when configured, Basic authentication and same-origin POST validation are required.
- Added baseline security headers and request-size/content-type checks for admin forms.
- Updated setup/security documentation.

## Verification performed

- Python compilation: passed.
- Automated regression tests: **30/30 passed**.
- Main route, calculator result, report, CSV, listing filters, admin add/delete/reset and public admin access tests: passed.
- The project uses only Python's standard library; Streamlit/Flask/Django are not required.

## Still outside this build's scope

The included land prices remain illustrative sample data. This version does not contain live property listings, a real GIS map, complete district/city coverage, a trained ML model, verified circle rates, or construction-approved architectural drawings. Those are feature/data expansions, not runtime defects in the existing prototype.
