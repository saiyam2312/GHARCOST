"""Pure-Python calculation engine for GharCost India.

Uses only the Python standard library. Inputs and every derived result are
validated so malformed or extreme values cannot silently produce NaN/Infinity.
"""
from __future__ import annotations

import math
from typing import Any

AREA_TO_SQFT = {
    "sq ft": 1.0,
    "sq yd": 9.0,
    "sq m": 10.7639104167,
}

QUALITY_RATES = {
    "Basic": 1500.0,
    "Standard": 1900.0,
    "Premium": 2500.0,
}

# Guardrails keep the calculator useful for normal property projects while
# preventing nonsensical values and overflow from untrusted HTTP input.
MAX_PLOT_AREA = 10_000_000.0
MAX_BUILTUP_AREA = 10_000_000.0
MAX_RATE_PER_SQFT = 100_000_000.0
MAX_ALLOWANCE_PCT = 100.0


def _finite_number(name: str, value: Any) -> float:
    """Convert an input to a finite float or raise a helpful ValueError."""
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must be a valid number.") from exc
    if not math.isfinite(number):
        raise ValueError(f"{name} must be a finite number (not NaN or Infinity).")
    return number


def _checked_result(values: dict[str, float]) -> dict[str, float]:
    """Reject any non-finite calculation result before it reaches the UI."""
    for name, value in values.items():
        if not math.isfinite(value):
            raise ValueError(f"The calculated {name.lower()} is outside the supported range. Reduce the input values.")
    return values


def calculate_costs(
    plot_area: float,
    area_unit: str,
    land_rate_per_sqft: float,
    builtup_area: float,
    quality: str,
    custom_construction_rate: float = 0,
    acquisition_pct: float = 0,
    site_pct: float = 0,
    professional_pct: float = 0,
    utilities_pct: float = 0,
    contingency_pct: float = 0,
    uncertainty_pct: float = 0,
) -> dict[str, float]:
    """Calculate an itemized home budget in INR.

    Land area is converted to square feet before multiplying by land rate.
    Acquisition applies to land cost. Site development, professional fees and
    utilities apply to base construction. Contingency applies once to the
    pre-contingency subtotal. The uncertainty band is separate.
    """
    numeric_inputs = {
        "Plot area": plot_area,
        "Land rate": land_rate_per_sqft,
        "Built-up area": builtup_area,
        "Custom construction rate": custom_construction_rate,
        "Acquisition allowance": acquisition_pct,
        "Site development allowance": site_pct,
        "Professional fee allowance": professional_pct,
        "Utilities allowance": utilities_pct,
        "Contingency": contingency_pct,
        "Uncertainty band": uncertainty_pct,
    }
    values = {name: _finite_number(name, value) for name, value in numeric_inputs.items()}

    if values["Plot area"] <= 0:
        raise ValueError("Plot area must be greater than zero.")
    if values["Plot area"] > MAX_PLOT_AREA:
        raise ValueError(f"Plot area cannot exceed {MAX_PLOT_AREA:,.0f} in the selected unit.")
    if values["Built-up area"] <= 0:
        raise ValueError("Built-up area must be greater than zero.")
    if values["Built-up area"] > MAX_BUILTUP_AREA:
        raise ValueError(f"Built-up area cannot exceed {MAX_BUILTUP_AREA:,.0f} sq ft.")

    for name in ("Land rate", "Custom construction rate"):
        if values[name] < 0:
            raise ValueError(f"{name} cannot be negative.")
        if values[name] > MAX_RATE_PER_SQFT:
            raise ValueError(f"{name} cannot exceed ₹{MAX_RATE_PER_SQFT:,.0f} per sq ft.")

    if area_unit not in AREA_TO_SQFT:
        raise ValueError("Choose sq ft, sq yd or sq m as the plot-area unit.")
    if quality not in QUALITY_RATES:
        raise ValueError("Choose Basic, Standard or Premium construction quality.")

    allowance_names = (
        "Acquisition allowance", "Site development allowance",
        "Professional fee allowance", "Utilities allowance",
        "Contingency", "Uncertainty band",
    )
    for name in allowance_names:
        if not 0 <= values[name] <= MAX_ALLOWANCE_PCT:
            raise ValueError(f"{name} must be between 0 and 100 percent.")

    plot_sqft = values["Plot area"] * AREA_TO_SQFT[area_unit]
    land_cost = plot_sqft * values["Land rate"]
    construction_rate = values["Custom construction rate"] or QUALITY_RATES[quality]
    base_construction = values["Built-up area"] * construction_rate

    acquisition = land_cost * values["Acquisition allowance"] / 100
    site = base_construction * values["Site development allowance"] / 100
    professional = base_construction * values["Professional fee allowance"] / 100
    utilities = base_construction * values["Utilities allowance"] / 100

    pre_contingency = land_cost + acquisition + base_construction + site + professional + utilities
    contingency = pre_contingency * values["Contingency"] / 100
    expected_total = pre_contingency + contingency
    uncertainty = values["Uncertainty band"] / 100

    result = {
        "Plot area (sq ft)": plot_sqft,
        "Land cost": land_cost,
        "Acquisition allowance": acquisition,
        "Base construction": base_construction,
        "Site development": site,
        "Professional fees": professional,
        "Utilities / approvals allowance": utilities,
        "Contingency": contingency,
        "Expected total": expected_total,
        "Lower estimate": expected_total * (1 - uncertainty),
        "Upper estimate": expected_total * (1 + uncertainty),
        "Construction rate (INR/sq ft)": construction_rate,
    }
    return _checked_result(result)


def validate_state_data(states: list[str], expected_total: int = 36) -> None:
    """Raise ValueError when the India State/UT selector data is incomplete."""
    if not isinstance(states, list) or any(not isinstance(item, str) or not item.strip() for item in states):
        raise ValueError("State/UT data must be a list of non-empty names.")
    if len(states) != expected_total or len(set(states)) != expected_total:
        raise ValueError(f"Expected {expected_total} unique States/UTs; found {len(states)} entries.")
