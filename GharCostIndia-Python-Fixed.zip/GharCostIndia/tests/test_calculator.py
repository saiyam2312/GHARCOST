import sys
import unittest
import math
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from calculator import calculate_costs, validate_state_data
import json


class CalculatorTests(unittest.TestCase):
    def test_square_yard_conversion(self):
        result = calculate_costs(100, "sq yd", 1000, 500, "Basic")
        self.assertEqual(result["Plot area (sq ft)"], 900)
        self.assertEqual(result["Land cost"], 900000)

    def test_square_metre_conversion(self):
        result = calculate_costs(10, "sq m", 100, 100, "Basic")
        self.assertAlmostEqual(result["Plot area (sq ft)"], 107.639104167)

    def test_cost_components_reconcile(self):
        result = calculate_costs(100, "sq yd", 1000, 500, "Basic", acquisition_pct=5,
                                 site_pct=5, professional_pct=5, utilities_pct=3, contingency_pct=10)
        keys = ["Land cost", "Acquisition allowance", "Base construction", "Site development",
                "Professional fees", "Utilities / approvals allowance", "Contingency"]
        self.assertAlmostEqual(sum(result[key] for key in keys), result["Expected total"])

    def test_custom_rate_overrides_quality(self):
        result = calculate_costs(100, "sq ft", 100, 500, "Basic", custom_construction_rate=2200)
        self.assertEqual(result["Construction rate (INR/sq ft)"], 2200)
        self.assertEqual(result["Base construction"], 1100000)

    def test_negative_values_rejected(self):
        with self.assertRaises(ValueError):
            calculate_costs(-1, "sq ft", 100, 500, "Basic")

    def test_nan_rejected(self):
        with self.assertRaises(ValueError):
            calculate_costs(float("nan"), "sq ft", 100, 500, "Basic")

    def test_infinity_and_extreme_finite_inputs_rejected(self):
        for value in (float("inf"), float("-inf"), 1e308):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    calculate_costs(value, "sq ft", 100, 500, "Basic")

    def test_every_calculated_value_is_finite(self):
        result = calculate_costs(1000, "sq yd", 100000, 5000, "Premium",
                                 acquisition_pct=100, site_pct=100,
                                 professional_pct=100, utilities_pct=100,
                                 contingency_pct=100, uncertainty_pct=100)
        self.assertTrue(all(math.isfinite(value) for value in result.values()))

    def test_extreme_rate_rejected(self):
        with self.assertRaises(ValueError):
            calculate_costs(100, "sq yd", 1e200, 500, "Basic")

    def test_invalid_area_unit_rejected(self):
        with self.assertRaises(ValueError):
            calculate_costs(100, "acre", 100, 500, "Basic")

    def test_percentage_limit(self):
        with self.assertRaises(ValueError):
            calculate_costs(100, "sq ft", 100, 500, "Basic", contingency_pct=101)

    def test_all_states_present(self):
        states = json.loads((Path(__file__).resolve().parents[1] / "data" / "states.json").read_text(encoding="utf-8"))
        validate_state_data(states)

    def test_all_location_states_exist_in_state_selector(self):
        data_dir = Path(__file__).resolve().parents[1] / "data"
        states = json.loads((data_dir / "states.json").read_text(encoding="utf-8"))
        locations = json.loads((data_dir / "locations.json").read_text(encoding="utf-8"))
        self.assertTrue(set(locations).issubset(set(states)))
        for districts in locations.values():
            self.assertIsInstance(districts, dict)
            for cities in districts.values():
                self.assertIsInstance(cities, list)
                self.assertTrue(all(isinstance(city, str) and city.strip() for city in cities))


if __name__ == "__main__":
    unittest.main()
