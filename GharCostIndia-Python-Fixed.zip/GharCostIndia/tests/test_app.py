import json
import base64
import os
import sys
import threading
import unittest
import urllib.request
import urllib.parse
import urllib.error
from unittest import mock
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import app


class WebSmokeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original_listings = app.LISTINGS_FILE.read_text(encoding="utf-8")
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), app.GharCostHandler)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)
        app.LISTINGS_FILE.write_text(cls.original_listings, encoding="utf-8")

    def get(self, path):
        with urllib.request.urlopen(self.base + path, timeout=3) as response:
            return response.status, response.headers.get("Content-Type", ""), response.read()

    def test_home_page(self):
        status, content_type, body = self.get("/")
        self.assertEqual(status, 200)
        self.assertIn("text/html", content_type)
        self.assertIn(b"GharCost India", body)

    def test_all_main_pages_render(self):
        for path in ("/?page=explore", "/?page=land", "/?page=designs", "/?page=calculator", "/?page=admin"):
            with self.subTest(path=path):
                status, content_type, body = self.get(path)
                self.assertEqual(status, 200)
                self.assertIn("text/html", content_type)
                self.assertIn(b"GharCost India", body)

    def test_calculator_page(self):
        status, _, body = self.get("/?page=calculator")
        self.assertEqual(status, 200)
        self.assertIn(b"Complete home-cost calculator", body)

    def test_calculation_result(self):
        status, _, body = self.get("/?page=calculator&plot_area=100&area_unit=sq%20yd&land_rate=1000&builtup=500&quality=Basic")
        self.assertEqual(status, 200)
        self.assertIn("₹900,000".encode(), body)

    def test_csv_export(self):
        status, content_type, body = self.get("/export.csv?plot_area=100&area_unit=sq%20yd&land_rate=1000&builtup=500&quality=Basic")
        self.assertEqual(status, 200)
        self.assertIn("text/csv", content_type)
        self.assertIn(b"Land cost", body)

    def test_health_route(self):
        status, content_type, body = self.get("/health")
        self.assertEqual(status, 200)
        self.assertIn(b"OK", body)

    def test_printable_report(self):
        status, content_type, body = self.get("/report?plot_area=100&area_unit=sq%20yd&land_rate=1000&builtup=500&quality=Basic")
        self.assertEqual(status, 200)
        self.assertIn("text/html", content_type)
        self.assertIn(b"Cost Estimate", body)

    def test_report_rejects_non_finite_inputs(self):
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.get("/report?plot_area=1e999&area_unit=sq%20yd&land_rate=100&builtup=500&quality=Basic")
        self.assertEqual(error.exception.code, 400)

    def test_csv_rejects_non_finite_inputs(self):
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.get("/export.csv?plot_area=100&area_unit=sq%20yd&land_rate=NaN&builtup=500&quality=Basic")
        self.assertEqual(error.exception.code, 400)

    def test_explore_city_filter_is_applied(self):
        status, _, body = self.get("/?page=explore&state=Haryana&district=Mahendragarh&city=Narnaul")
        self.assertEqual(status, 200)
        self.assertIn(b"Residential plot - sample", body)
        self.assertIn(b"Narnaul", body)
        self.assertNotIn(b"Corner plot - sample", body)

    def test_explore_city_filter_can_be_all_cities(self):
        status, _, body = self.get("/?page=explore&state=Haryana&district=Mahendragarh&city=All%20cities")
        self.assertEqual(status, 200)
        self.assertIn(b"1 sample record(s)", body)

    def test_admin_add_and_delete(self):
        payload = urllib.parse.urlencode({
            "title": "HTTP test sample", "state": "Haryana", "district": "Mahendragarh",
            "city": "Narnaul", "locality": "Test locality", "area_sqyd": "100", "price": "900000"
        }).encode()
        request = urllib.request.Request(self.base + "/admin/add", data=payload, method="POST",
                                         headers={"Content-Type": "application/x-www-form-urlencoded", "Origin": self.base})
        with urllib.request.urlopen(request, timeout=3) as response:
            self.assertEqual(response.status, 200)
            self.assertIn(b"Sample listing added successfully", response.read())
        new_item = next(x for x in app.load_listings() if x["title"] == "HTTP test sample")
        delete_payload = urllib.parse.urlencode({"id": str(new_item["id"])}).encode()
        delete_request = urllib.request.Request(self.base + "/admin/delete", data=delete_payload, method="POST",
                                                headers={"Content-Type": "application/x-www-form-urlencoded", "Origin": self.base})
        with urllib.request.urlopen(delete_request, timeout=3) as response:
            self.assertEqual(response.status, 200)
            self.assertIn(b"Listing deleted successfully", response.read())
        self.assertFalse(any(x["id"] == new_item["id"] for x in app.load_listings()))

    def test_admin_reset_restores_seed_records(self):
        payload = b""
        request = urllib.request.Request(self.base + "/admin/reset", data=payload, method="POST",
            headers={"Content-Type": "application/x-www-form-urlencoded", "Origin": self.base})
        with urllib.request.urlopen(request, timeout=3) as response:
            self.assertEqual(response.status, 200)
            self.assertIn(b"Sample listings reset successfully", response.read())
        seed = json.loads((ROOT / "data" / "listings.seed.json").read_text(encoding="utf-8"))
        self.assertEqual(app.load_listings(), seed)

    def test_local_admin_rejects_cross_origin_or_missing_origin_post(self):
        request = urllib.request.Request(self.base + "/admin/reset", data=b"", method="POST",
            headers={"Content-Type": "application/x-www-form-urlencoded"})
        with self.assertRaises(urllib.error.HTTPError) as error:
            urllib.request.urlopen(request, timeout=3)
        self.assertEqual(error.exception.code, 403)

    def test_admin_rejects_nan_and_infinity(self):
        original_count = len(app.load_listings())
        for bad_value in ("NaN", "Infinity", "1e999"):
            payload = urllib.parse.urlencode({
                "title": "Invalid numeric sample", "state": "Haryana", "district": "Mahendragarh",
                "city": "Narnaul", "locality": "Test locality", "area_sqyd": "100", "price": bad_value
            }).encode()
            request = urllib.request.Request(self.base + "/admin/add", data=payload, method="POST",
                                             headers={"Content-Type": "application/x-www-form-urlencoded", "Origin": self.base})
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.urlopen(request, timeout=3)
            self.assertEqual(error.exception.code, 400)
        self.assertEqual(len(app.load_listings()), original_count)

    def test_public_admin_is_disabled_without_password(self):
        class RemoteOnlyHandler(app.GharCostHandler):
            def _client_is_local(self):
                return False

        with mock.patch.dict(os.environ, {"ADMIN_PASSWORD": ""}):
            server = ThreadingHTTPServer(("127.0.0.1", 0), RemoteOnlyHandler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                url = f"http://127.0.0.1:{server.server_address[1]}/?page=admin"
                with self.assertRaises(urllib.error.HTTPError) as error:
                    urllib.request.urlopen(url, timeout=3)
                self.assertEqual(error.exception.code, 503)
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=2)

    def test_public_admin_requires_password_and_same_origin_post(self):
        class RemoteOnlyHandler(app.GharCostHandler):
            def _client_is_local(self):
                return False

        with mock.patch.dict(os.environ, {"ADMIN_PASSWORD": "test-only-password"}):
            server = ThreadingHTTPServer(("127.0.0.1", 0), RemoteOnlyHandler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                base = f"http://127.0.0.1:{server.server_address[1]}"
                with self.assertRaises(urllib.error.HTTPError) as unauthorized:
                    urllib.request.urlopen(base + "/?page=admin", timeout=3)
                self.assertEqual(unauthorized.exception.code, 401)

                token = base64.b64encode(b"admin:test-only-password").decode("ascii")
                auth_header = {"Authorization": "Basic " + token}
                request = urllib.request.Request(base + "/?page=admin", headers=auth_header)
                with urllib.request.urlopen(request, timeout=3) as response:
                    self.assertEqual(response.status, 200)

                payload = urllib.parse.urlencode({"id": "1"}).encode()
                cross_site = urllib.request.Request(base + "/admin/delete", data=payload, method="POST",
                    headers={**auth_header, "Content-Type": "application/x-www-form-urlencoded",
                             "Origin": "https://attacker.invalid"})
                with self.assertRaises(urllib.error.HTTPError) as blocked:
                    urllib.request.urlopen(cross_site, timeout=3)
                self.assertEqual(blocked.exception.code, 403)

                same_site = urllib.request.Request(base + "/admin/reset", data=b"", method="POST",
                    headers={**auth_header, "Content-Type": "application/x-www-form-urlencoded",
                             "Origin": base})
                opener = urllib.request.build_opener(urllib.request.HTTPRedirectHandler())
                with opener.open(same_site, timeout=3) as response:
                    self.assertEqual(response.status, 200)
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=2)


if __name__ == "__main__":
    unittest.main()
